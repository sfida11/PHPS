<!DOCTYPE html>
<html lang="ja">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>お問い合わせフォーム</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="style.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<div class="content-box">
				<h2>お問い合わせフォーム</h2>
				<form id="contact_form" method="post" action="index.php" accept-charset="utf-8">
					<div class="form-group">
						<label>お名前</label>
						<input name="name" type="text" class="form-text" placeholder="お名前" required="required" />
					</div>
					<div class="form-group">
						<label>メールアドレス</label>
						<input name="email" type="email" class="form-text" placeholder="メールアドレス" required="required" />
					</div>
					<div class="form-group">
						<label>お問い合わせ内容</label>
						<textarea name="message" class="form-text" required="required"> </textarea>
					</div>
					<div class="form-group">
						<input type="submit" class="btn-submit" value="送信" />
					</div>
				</form>
			</div>
			<div class="content-box">
				<h2>送信結果表示</h2>
				<table>
					<tbody>
						<tr>
							<th>お名前</th>
							<td><?php echo htmlspecialchars($_POST["name"], ENT_QUOTES);?></td>
						</tr>
						<tr>
							<th>メールアドレス</th>
							<td><?php echo htmlspecialchars($_POST["email"], ENT_QUOTES);?></td>
						</tr>
						<tr>
							<th>お問い合わせ内容</th>
							<td><?php echo htmlspecialchars($_POST["message"], ENT_QUOTES);?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</body>
</html>
