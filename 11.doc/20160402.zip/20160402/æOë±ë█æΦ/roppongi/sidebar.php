	<?php
		global $home_var;
		global $template_var;
	?>
	<div class="sidebar_wrap">
	<div class="sidebar">
		<header class="header">
			<h1 class="header_h1"><a href="<?php echo $home_var; ?>"><img src="<?php echo $template_var; ?>/img/logo.png" width="100%" class="hO02" alt="プレジール"></a></h1>
			<nav class="header_nav">
				<ul class="header_nav_ul">
					<li class="header_nav_ul_li">
						<p><img src="<?php echo $template_var; ?>/img/gnavi/gnavi01_no.png" width="100%" class="over" id="ul01" alt="会社情報"></p>
					</li>
					<li class="header_nav_ul_li" >
						<p><img src="<?php echo $template_var; ?>/img/gnavi/gnavi02_no.png" width="100%" class="over" id="ul02" alt="事業紹介"></p>
					</li>
					<li class="header_nav_ul_li">
						<p><a href="<?php echo $home_var; ?>/recruit"><img src="<?php echo $template_var; ?>/img/gnavi/gnavi03_no.png" width="100%" class="over" alt="採用情報"></a></p>
					</li>
					<li class="header_nav_ul_li">
						<p><img src="<?php echo $template_var; ?>/img/gnavi/gnavi04_no.png" width="100%" class="over" id="ul03" alt="お知らせ"></p>

					</li>
					<li class="header_nav_ul_li">
						<p><a href="<?php echo $home_var; ?>/form"><img src="<?php echo $template_var; ?>/img/gnavi/gnavi05_no.png" width="100%" class="over" alt="お問い合わせ"></a></p>
					</li>
				</ul>
			</nav>

			<h1 class="facebook_link">
				<a href="https://www.facebook.com/pages/%E6%A0%AA%E5%BC%8F%E4%BC%9A%E7%A4%BE%E3%83%97%E3%83%AC%E3%82%B8%E3%83%BC%E3%83%AB/1677965695807046" title="&#x682a;&#x5f0f;&#x4f1a;&#x793e;&#x30d7;&#x30ec;&#x30b8;&#x30fc;&#x30eb;" target="_TOP">
					<div align="center">
						<img class="img" src="https://badge.facebook.com/badge/1677965695807046.11142.1824026977.png" style="border: 0px;"  alt=""/>
					</div>
				</a><br />
			</h1>



		</header>
	</div>
	<ul class="hover_ul" id="hover_ul01">
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo $home_var; ?>/culture">社風</a></li>
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo $home_var; ?>/infomation">会社概要</a></li>
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo $home_var; ?>/philosophy">企業理念</a></li>
	</ul>
	<ul class="hover_ul" id="hover_ul02">
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo $home_var; ?>/system_service">システムサービス部</a></li>
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo $home_var; ?>/travel_service">トラベルサービス部</a></li>
	</ul>
	<ul class="hover_ul" id="hover_ul03">
		<li class="hover_ul_li"><a class="hover_ul_li_a" href="<?php echo get_year_link( false ); ?>">過去記事一覧</a></li>
	</ul>
	</div>