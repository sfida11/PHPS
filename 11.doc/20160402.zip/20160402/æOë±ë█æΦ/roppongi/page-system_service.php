<?php
/*
Template Name: system_service
*/
?>
<?php get_header(); ?>
<?php get_sidebar(); ?>
<?php
global $home_var;
global $template_var;
?>

	<div class="content">
		<section>
			<div class="head_box">
				<div class="breadcrumb clearfix">
					<div itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
						<a href="<?php echo $home_var; ?>" itemprop="url"><span itemprop="title">ホーム</span></a>
					</div>
					-
					<div itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
						<a href="<?php echo $home_var; ?>/system_service" itemprop="url"><span itemprop="title">システムサービス部</span></a>
					</div>
				</div>
				<h1 class="ttl00">システムサービス部<br /><span class="ttl00_en">SYSTEM DEVELOPMENT &amp; OPERATION</span></h1>
			</div>

			<p class="mainImg"><img src="<?php echo $template_var; ?>/img/visual_sistem.jpg" width="100%" class="mainImg_img" alt="システムサービス部"></p>

		



			<div class="cmnBox">
				<section>
					<div class="clearfix">
						<figure class="figureRight">
							<p><img src="<?php echo $template_var; ?>/img/img_sistem01.png" width="100%" alt="プログラム開発、インフラ構築、維持管理テクニカルサポート"></p>
						</figure>
						<div class="of">
							<h1 class="ttl01">事業内容</h1>
							<p>システム開発は多岐にわたり、プログラム開発からインフラ構築、維持管理、<br />テクニカルサポートまで幅広く対応しています。<br />プログラム開発やインフラ構築にとどまらず、<br />プロジェクトマネジメントにも携わることで、私たちの価値を高めてきました。</p>
						</div>
					</div>
				</section>
			</div>

			<div class="cmnBox mb30">
				<ul class="pic01">
					<li class="taL">
						<h1 class="ttl02 orange">データセンタ老朽化に伴う移転プロジェクト</h1>
						<p>現存の物理サーバと仮想サーバを新データセンタの仮想サーバに<br />移行するプロジェクト。（P2V,V2V）<br />サーバの構築手順書作成や構築作業のほか、現存システムの維持管理。</p>
					</li>
					<li class="taL">
						<h1 class="ttl02 orange">通信キャリアのISP基盤構築プロジェクト</h1>
						<p>サービス追加、機能改善など、多数案件を横断的な観点で<br />提案から見積、設計、構築作業完了までを推進する統制業務。<br />主には、スケジュール立案、進捗管理、課題事項の消化推進、品質管理、<br />業務効率化提案など。</p>
					</li>
				</ul>
			</div>

			<div class="cmnBox03">
				<section>
					<div class="clearfix">
						<figure class="figureRight">
							<p><img src="<?php echo $template_var; ?>/img/img_sistem02.jpg" width="100%" alt="プロジェクトマネジメント"></p>
						</figure>
						<div class="of">
							<h1 class="ttl03">プロジェクトマネジメント</h1>
							<p class="mb20">プログラム開発やインフラ構築にとどまらず、 プロジェクトマネジメントにも携わることで、 私たちの価値を高めてきました。<br />単なるシステムの提供だけではなく、お客さまの問題点を改善し、 利益に結びつける提案を行ない、お客さまから評価して頂いています。</p>
							<p>例えば、ISP基盤構築プロジェクトでは、サービス追加、機能改善など、多数の案件を横断的な観点で提案から見積、設計、 構築作業までを推進する統制業務を担当しています。</p>
						</div>
					</div>
				</section>
			</div>

			<div class="cmnBox03">
				<section>
					<div class="clearfix">
						<figure class="figureRight">
							<p><img src="<?php echo $template_var; ?>/img/img_sistem03.jpg" width="100%" alt="インフラ構築"></p>
						</figure>
						<div class="of">
							<h1 class="ttl03">インフラ構築</h1>
							<p>アプリケーション・パッケージ実装に必要となる共通基盤、<br />サーバ・ネットワークの設計/構築を行います。<br />各種サーバー構築（DNS,DHCP,WSUS,AD,ファイル,IIS）及び仮想化、Cisco製ルータ、YAMAHA製ルータの設定を行います。</p>
						</div>
					</div>
				</section>	
			</div>

			<div class="cmnBox03">
				<section>
					<div class="clearfix">
						<figure class="figureRight">
							<p><img src="<?php echo $template_var; ?>/img/img_sistem04.jpg" width="100%" alt="アプリケーション開発"></p>
						</figure>
						<div class="of">
							<h1 class="ttl03">アプリケーション開発</h1>
							<p>業務系とWeb系システムにて開発実績があります。<br />AR等のモバイル関連アプリ開発などの成長分野のスキルも積極的に習得しています。 <br />個々の高い技術力と、リーダを中心とした強いチームワークでお客様の抱えている問題を<br />解決します。 </p>
						</div>
					</div>
				</section>	
			</div>

			<div class="cmnBox03 mb90">
				<section>
					<div class="clearfix">
						<figure class="figureRight">
							<p><img src="<?php echo $template_var; ?>/img/img_sistem05.jpg" width="100%" alt="運用サポート"></p>
						</figure>
						<div class="of">
							<h1 class="ttl03">運用サポート</h1>
							<p>お客様先常駐による日常の運用管理業務から、<br />ヘルプデスクやシステム監視、トラブル対応まで、<br />お客様のご要望に合わせた柔軟なサービスをご提供いたします。 </p>
						</div>
					</div>
				</section>	
			</div>
		</section>
	</div>

	<?php get_footer(); ?>