<!DOCTYPE HTML>
<html lang="ja">
<head>
<meta http-equiv="content-type" content="text/html" charset="utf-8" />
<title>Form input</title>
</head>
<body>
<form action="regist.php" method="post">
  Name:<br />
  <input type="text" name="name" size="30" value="" /><br />
  Mail Address:<br/>
  <input type="text" name="mail" id="mail" size="30" value="" /><br />
  Comment:<br />
  <textarea name="comment" cols="30" rows="5"></textarea><br />
  <br />
  <input type="submit" value="確認" />

  <br />
  <button type="button" id="btnSay">Alertを表示</button>

</form>
</body>
</html>
<script src="scripts/jquery-1.3.1.js" type="text/javascript"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $("#btnSay").click(function() {
      alert("Hello World!!!");
    })

    //メールアドレスのチェック
    $("#mail").change(function () {
        if($(this).val() && !$(this).val().match(/.+@.+\..+/g)){
            alert("メールアドレスの形式が異なります");
        }
    }).change();

  });
</script>
