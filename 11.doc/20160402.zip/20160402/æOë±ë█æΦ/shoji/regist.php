<html>
<head>
<meta http-equiv="content-type" content="text/html" charset="utf-8" />
<title>Form input</title>
</head>
<body>
<table border="1">
  <tr>
    <td>Name</td><td><?php echo $_POST["name"] ?></td>
  </tr>
  <tr>
    <td>Mail Address</td><td><?php echo $_POST["mail"] ?></td>
  </tr>
  <tr>
    <td>Comment</td><td><?php echo $_POST["comment"] ?></td>
  </tr>
</table>
</body>
</html>
